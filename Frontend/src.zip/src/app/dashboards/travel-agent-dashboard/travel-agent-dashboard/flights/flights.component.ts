import { Component } from '@angular/core';
import {  RouterModule } from '@angular/router';

@Component({
  selector: 'app-flights',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './flights.component.html',
  styleUrl: './flights.component.css'
})
export class FlightsdashComponent {

}
