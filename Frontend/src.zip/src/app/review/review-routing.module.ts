// import { Routes } from '@angular/router';
// import { ReviewListComponent } from './components/review-list/review-list.component';
// import { ReviewDetailComponent } from './components/review-detail/review-detail.component';
// import { ReviewFormComponent } from './components/review-form/review-form.component';

// export const reviewRoutes: Routes = [
//   { path: 'reviews', component: ReviewListComponent },
//   { path: 'reviews/new', component: ReviewFormComponent },
//   { path: 'reviews/:id', component: ReviewDetailComponent },
//   { path: 'reviews/edit/:id', component: ReviewFormComponent }
// ];
