package com.cts.project.Travelling_package.Model;



public enum PaymentType {
    ITINERARY,
    HOTEL,
    FLIGHT
}