package com.cts.project.Travelling_package.Model;

public interface Booking {
    int getQuantity();
    Long getBookingId();
}
