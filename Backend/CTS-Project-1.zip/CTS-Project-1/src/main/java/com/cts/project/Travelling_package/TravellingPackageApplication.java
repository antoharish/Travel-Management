package com.cts.project.Travelling_package;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravellingPackageApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravellingPackageApplication.class, args);


	}
}
